#include "layers.h"
int experiment();

volatile uint32_t cls = 0;

int main()
{
    //Configure HPM3 to count clock ticks
    neorv32_cpu_csr_write(CSR_MHPMEVENT3, 1 << HPMCNT_EVENT_CY); 

//    neorv32_cpu_csr_write(CSR_MHPMEVENT4, 1 << HPMCNT_EVENT_WAIT_DIS);
//    neorv32_cpu_csr_write(CSR_MHPMEVENT5, 1 << HPMCNT_EVENT_WAIT_LSU);
//    neorv32_cpu_csr_write(CSR_MHPMEVENT6, 1 << HPMCNT_EVENT_WAIT_ALU);
//    neorv32_cpu_csr_write(CSR_MHPMEVENT7, 1 << HPMCNT_EVENT_IR);
    
    // Enable ALL counters (including HPMs)
    neorv32_cpu_csr_write(CSR_MCOUNTINHIBIT, 0);

    // Clear HPM3
    neorv32_cpu_csr_write(CSR_MHPMCOUNTER3,  0);
    
    neorv32_uart0_printf("Result: %d\n", experiment());

    neorv32_uart0_printf("Execution Cycles: %d\n", neorv32_cpu_csr_read(CSR_MHPMCOUNTER3));
    
//    amowrite((uint32_t)&cls, 1);
//    amowrite((uint32_t)&cls, neorv32_cpu_csr_read(CSR_MHPMCOUNTER4));
//    amowrite((uint32_t)&cls, 2);
//    amowrite((uint32_t)&cls, neorv32_cpu_csr_read(CSR_MHPMCOUNTER5));
//    amowrite((uint32_t)&cls, 3);
//    amowrite((uint32_t)&cls, neorv32_cpu_csr_read(CSR_MHPMCOUNTER6));
//    amowrite((uint32_t)&cls, 4);
//    amowrite((uint32_t)&cls, neorv32_cpu_csr_read(CSR_MHPMCOUNTER7));

    // Stop all CPU counters including HPMs
    neorv32_cpu_csr_write(CSR_MCOUNTINHIBIT, -1);

    return 0;
}

int experiment()
{
    int res = 0;

    int Quant[1944];
    tensor_int Quant_tensor; // zero and scale are invalid here
    Quant_tensor.array = &Quant[0];
    #if (bit_width == 1)
    Quant_tensor.scale = 2;
    Quant_tensor.zero  = 0.5;
    #elif (bit_width == 2)
    Quant_tensor.scale = 1;
    Quant_tensor.zero  = 1;
    #elif (bit_width == 4)
    Quant_tensor.scale = 1/7.0;
    Quant_tensor.zero  = 7;
    #endif

    conv1_layer(&Quant_tensor);

    conv2_layer(&Quant_tensor);

    fc1_layer(&Quant_tensor);

    fc2_layer(&Quant_tensor);

    res = fc3_layer(&Quant_tensor);

//    neorv32_uart0_printf("%d, %d\n", Quant_tensor.RW, Quant_tensor.CL);
//    for(int q=0; q<Quant_tensor.CL*Quant_tensor.RW; q++)
//    {
//        neorv32_uart0_printf("%d,\n", Quant_tensor.array[q]);
//    }


    return res;

//    printf("%d, %d\n", Quant_tensor->CL, Quant_tensor->RW);
//    int test = 0;
//    for(int q=0; q<Quant_tensor->CL; q++)
//    {
//        test += Quant_tensor->array[q];
//    }
//    printf("%d\n", test);

}

