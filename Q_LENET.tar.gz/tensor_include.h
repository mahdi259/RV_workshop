#pragma once // This solves redefinition error which is caused by multiple includings
// --------------------------------------

struct tensor_float
{
    /** Pointer to array of tensor values flattened in row major order. */
    float * array;
    
    /** Scale of the quantization. */
    float scale;

    /** Zero point of the quantization. */
    float zero;

    /** Number of rows of tensor. */
    int RW;

    /** Number of columns of tensor. */
    int CL;
};

typedef struct tensor_float tensor_float;

// --------------------------------------
struct tensor_int
{
    /** Pointer to array of tensor values flattened in row major order. */
    int * array;

    /** Scale of the quantization. */
    float scale;

    /** Zero point of the quantization. */
    float zero;

    /** Number of rows of tensor. */
    int RW;

    /** Number of columns of tensor. */
    int CL;
};

typedef struct tensor_int tensor_int;
