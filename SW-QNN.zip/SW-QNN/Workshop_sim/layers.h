#include <stdbool.h>
#include <neorv32.h>
#include <math.h>
#include "tensor_include.h"

#define max_transpose_numel 1944
// --------------------------------------
#define bit_width 4
// --------------------------------------
#define ULPPACK
// --------------------------------------
//#define SW
#ifndef SW
#define HW
#endif
// --------------------------------------

#define conv1_tensor conv1_ulp_tensor
#define conv2_tensor conv2_ulp_tensor
#define FC1_tensor FC1_ulp_tensor
#define FC2_tensor FC2_ulp_tensor
#define FC3_tensor FC3_ulp_tensor
#define Tensor_PACK Tensor_ULPPACK_asym

#ifdef SW
#define GEMM ulp_matrix_multiply_x_yT
#else
#define GEMM ulp_matrix_multiply_x_yT_CI
#endif


// --------------------------------------

void amowrite(uint32_t addr, uint32_t wdata);

void conv1_layer(tensor_int* Quant_tensor);
void conv2_layer(tensor_int* Quant_tensor);
void fc1_layer(tensor_int* Quant_tensor);
void fc2_layer(tensor_int* Quant_tensor);
int  fc3_layer(tensor_int* Quant_tensor);

void Quant_1bit(tensor_int* x, bool polar_clip);

void Quant_2bit(tensor_int* x, bool polar_clip);

void Quant_4bit(tensor_int* x, bool polar_clip);

void Unfold(tensor_int* o, tensor_int* x, int conv_win, int in_dim);

void Calc_inp_const(tensor_float* o, tensor_int* x, tensor_int* w);

void Tensor_ULPPACK_asym(tensor_int* x);

void ulp_matrix_multiply_x_yT(tensor_int* o, tensor_int* x, tensor_int* y);

void ulp_matrix_multiply_x_yT_CI(tensor_int* o, tensor_int* x, tensor_int* y);

void Dequantize_res(tensor_float* o, tensor_int* x, tensor_int* y, tensor_float* const1, tensor_float* const2, float const3);

void Batchnorm(tensor_float* x, tensor_float* batchnorm, bool Tensor_norm);

void Bimod_clamp_1bit(tensor_int* o, tensor_float* x);

void Trimod_clamp_2bit(tensor_int* o, tensor_float* x);

void Heptamod_clamp_4bit(tensor_int* o, tensor_float* x);

void Transpose(tensor_int* x);

void Maxpool2D(tensor_int* x, int in_dim);

