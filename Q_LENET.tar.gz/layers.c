#include "layers.h"

#if (bit_width == 1)
#include "parameters1bit.h"
#elif (bit_width == 2)
#include "parameters2bit.h"
#elif (bit_width == 4)
#include "parameters4bit.h"
#endif


void conv1_layer(tensor_int* Quant_tensor)
{

    // ---- Polar Quantization
    // ---- s = 255/2, z = -1
    #if (bit_width == 1)
    Quant_1bit(&input_tensor, true);
    #elif (bit_width == 2)
    Quant_2bit(&input_tensor, true);
    #elif (bit_width == 4)
    Quant_4bit(&input_tensor, true);
    #endif

//    printf("RW:%d, CL:%d\n", input_tensor.RW, input_tensor.CL);
//    for(int i=0; i<input_tensor.RW*input_tensor.CL; i++)
//    {
//        printf("%d,\n", input_tensor.array[i]);
//    }      

    // ------------------------------
    // ---------- CONV 1 ------------
    // ------------------------------
    // ---- Quantize numbers to positive numbers
    #if (bit_width == 1)
    input_tensor.scale = 2;
    input_tensor.zero  = 0.5;
    #elif (bit_width == 2)
    input_tensor.scale = 1;
    input_tensor.zero  = 1;
    #elif (bit_width == 4)
    input_tensor.scale = 1/7.0;
    input_tensor.zero  = 7;
    #endif

    
    #if (bit_width == 1)
    Quant_1bit(&input_tensor, false);
    #elif (bit_width == 2)
    Quant_2bit(&input_tensor, false);
    #elif (bit_width == 4)
    Quant_4bit(&input_tensor, false);
    #endif
    
//     printf("RW:%d, CL:%d\n", input_tensor.RW, input_tensor.CL);
//     for(int i=0; i<input_tensor.RW*input_tensor.CL; i++)
//     {
//         printf("%d,\n", input_tensor.array[i]);
//     }

    // ---- Unfold
    // ---- Then input is unfolded to change CONV into GEMM. Unfolded input is 324 x 9 in size.
    int modinp[2916];
    tensor_int modinp_tensor = {&modinp[0],0,0,324,9};

    Unfold(&modinp_tensor, &input_tensor, 3, 20);
//         printf("%d, %d,\n", modinp_tensor.RW, modinp_tensor.CL);
//     printf("RW:%d, CL:%d\n", input_tensor.RW, input_tensor.CL);
//     for(int i=0; i<modinp_tensor.RW*modinp_tensor.CL; i++)
//     {
//         printf("%d,\n", modinp_tensor.array[i]);
//     }
    // ---- Constant calculation
    // Const1_1 is calculated in runtime because input is not known in advance.
    float const1[324];
    tensor_float const1_tensor = {&const1[0],0,0,1,324};

//    Calc_inp_const(&const1_tensor, &modinp_tensor, &conv1_tensor);
    Calc_inp_const(&const1_tensor, &modinp_tensor, &conv1_tensor);

//     printf("RW:%d, CL:%d\n", const1_tensor.RW, const1_tensor.CL);
//     for(int i=0; i<const1_tensor.RW*const1_tensor.CL; i++)
//     {
//         printf("%f,\n", const1_tensor.array[i]);
//     }

    // ---- Tensor ULPPACK
    Tensor_PACK(&modinp_tensor);
//    printf("RW:%d, CL:%d\n", modinp_tensor.RW, modinp_tensor.CL);
//    for(int i=0; i<modinp_tensor.RW*modinp_tensor.CL; i++)
//    {
//        printf("%u,\n", modinp_tensor.array[i]);
//    }
    

    // ---- Convolution
    // ---- Weights of Conv1 are transposed i.e.
    // ---- columns are in rows one after the other.
    // allocate 324*6 words of memory
    GEMM(Quant_tensor, &modinp_tensor, &conv1_tensor);


//    printf("RW:%d, CL:%d\n", Quant_tensor->RW, Quant_tensor->CL);
//    for(int i=0; i<Quant_tensor->RW*Quant_tensor->CL; i++)
//    {
//        printf("%d,\n", Quant_tensor->array[i]);
//    }
    
    // ---- Dequantize
    float Dequant[1944];
    tensor_float Dequant_tensor = {&Dequant[0],0,0,324,6};
    
    Dequantize_res(&Dequant_tensor, Quant_tensor, &conv1_tensor, &const1_tensor, &const2_1_tensor, const3_1);


//     printf("RW:%d, CL:%d\n", Dequant_tensor.RW, Dequant_tensor.CL);
//     for(int i=0; i<Dequant_tensor.RW*Dequant_tensor.CL; i++)
//     {
//         printf("%f,\n", Dequant_tensor.array[i]);
//     }

    // ---- Batchnorm
    Batchnorm(&Dequant_tensor, &batchnorm1_tensor, false);

//     printf("RW:%d, CL:%d\n", Dequant_tensor.RW, Dequant_tensor.CL);
//     for(int i=0; i<Dequant_tensor.RW*Dequant_tensor.CL; i++)
//     {
//         printf("%f,\n", Dequant_tensor.array[i]);
//     }

    // ---- Quantize numbers
    #if (bit_width == 1)
    Bimod_clamp_1bit(Quant_tensor, &Dequant_tensor);
    #elif (bit_width == 2)
    Trimod_clamp_2bit(Quant_tensor, &Dequant_tensor);
    #elif (bit_width == 4)
    Heptamod_clamp_4bit(Quant_tensor, &Dequant_tensor);
    #endif
    
//     printf("RW:%d, CL:%d\n", Quant_tensor->RW, Quant_tensor->CL);
//     for(int i=0; i<Quant_tensor->RW*Quant_tensor->CL; i++)
//     {
//         printf("%d,\n", Quant_tensor->array[i]);
//     }

    // ---- Quantize numbers to positive number
    #if (bit_width == 1)
    Quant_1bit(Quant_tensor, false);
    #elif (bit_width == 2)
    Quant_2bit(Quant_tensor, false);
    #elif (bit_width == 4)
    Quant_4bit(Quant_tensor, false);
    #endif


    // ---- Transpose
    Transpose(Quant_tensor);


    // ---- Maxpool2D
    Maxpool2D(Quant_tensor, 18);

}


void conv2_layer(tensor_int* Quant_tensor)
{
    // ------------------------------
    // ---------- CONV 2 ------------
    // ------------------------------
    // ---- Unfold
    // ---- Then input is unfolded to change CONV into GEMM. Unfolded input is 36 x 96 in size.
    int modinp[3456];
    tensor_int modinp_tensor = {&modinp[0],2,0.5,36,96};
    #if (bit_width == 1)
    modinp_tensor.scale = 2;
    modinp_tensor.zero  = 0.5;
    #elif (bit_width == 2)
    modinp_tensor.scale = 1;
    modinp_tensor.zero  = 1;
    #elif (bit_width == 4)
    modinp_tensor.scale = 1/7.0;
    modinp_tensor.zero  = 7;
    #endif
    
    Unfold(&modinp_tensor, Quant_tensor, 4, 9);
    // array pointer of Quant_tensor was changed in Transpose function and Quant was freed there.


    // ---- Constant calculation
    // Const1_1 is calculated in runtime because input is not known in advance.
    float const1[36];
    tensor_float const1_tensor = {&const1[0],0,0,1,36};
    Calc_inp_const(&const1_tensor, &modinp_tensor, &conv2_tensor);


    // ---- Tensor ULPPACK
    Tensor_PACK(&modinp_tensor);

//     printf("RW:%d, CL:%d\n", modinp_tensor.RW, modinp_tensor.CL);
//     for(int i=0; i<modinp_tensor.RW*modinp_tensor.CL; i++)
//     {
//         printf("%u,\n", modinp_tensor.array[i]);
//     }
    // ---- Convolution
    // ---- Weights of Conv1 are transposed i.e.
    // ---- columns are in rows one after the other.
    // allocate 36*16 words of memory
    GEMM(Quant_tensor, &modinp_tensor, &conv2_tensor);
//    printf("RW:%d, CL:%d\n", Quant_tensor->RW, Quant_tensor->CL);
//    for(int i=0; i<Quant_tensor->RW*Quant_tensor->CL; i++)
//    {
//        printf("%d,\n", Quant_tensor->array[i]);
//    }
    // ---- Dequantize
    float Dequant[576];
    tensor_float Dequant_tensor = {&Dequant[0],0,0,36,16};
    Dequantize_res(&Dequant_tensor, Quant_tensor, &conv1_tensor, &const1_tensor, &const2_2_tensor, const3_2);
//     printf("RW:%d, CL:%d\n", Dequant_tensor.RW, Dequant_tensor.CL);
//     for(int i=0; i<Dequant_tensor.RW*Dequant_tensor.CL; i++)
//     {
//         printf("%f,\n", Dequant_tensor.array[i]);
//     }


    // ---- Batchnorm
    Batchnorm(&Dequant_tensor, &batchnorm2_tensor, false);
//     printf("BN\n");
//     printf("RW:%d, CL:%d\n", Dequant_tensor.RW, Dequant_tensor.CL);
//     for(int i=0; i<Dequant_tensor.RW*Dequant_tensor.CL; i++)
//     {
//         printf("%f,\n", Dequant_tensor.array[i]);
//     }

    // ---- Quantize numbers
    #if (bit_width == 1)
    Bimod_clamp_1bit(Quant_tensor, &Dequant_tensor);
    #elif (bit_width == 2)
    Trimod_clamp_2bit(Quant_tensor, &Dequant_tensor);
    #elif (bit_width == 4)
    Heptamod_clamp_4bit(Quant_tensor, &Dequant_tensor);
    #endif
//     printf("RW:%d, CL:%d\n", Quant_tensor->RW, Quant_tensor->CL);
//     for(int i=0; i<Quant_tensor->RW*Quant_tensor->CL; i++)
//     {
//         printf("%d,\n", Quant_tensor->array[i]);
//     }

    // ---- Quantize numbers to 0 and 1
    // ---- s = 2, z = 0.5
    #if (bit_width == 1)
    Quant_1bit(Quant_tensor, false);
    #elif (bit_width == 2)
    Quant_2bit(Quant_tensor, false);
    #elif (bit_width == 4)
    Quant_4bit(Quant_tensor, false);
    #endif

//    printf("RW:%d, CL:%d\n", Quant_tensor->RW, Quant_tensor->CL);
//    for(int i=0; i<Quant_tensor->RW*Quant_tensor->CL; i++)
//    {
//        printf("%d,\n", Quant_tensor->array[i]);
//    }

    // ---- Transpose
    Transpose(Quant_tensor);


    // ---- Maxpool2D
    Maxpool2D(Quant_tensor, 6);


    // ---- Flatten
    Quant_tensor->CL = Quant_tensor->CL * Quant_tensor->RW;
    Quant_tensor->RW = 1;

}


void fc1_layer(tensor_int* Quant_tensor)
{

    // ------------------------------
    // ----------- FC 1 -------------
    // -------- 144 -> 120 ----------

    // ---- Constant calculation
    // Const1_3 is calculated in runtime because input is not known in advance.
    float const1[1];
    tensor_float const1_tensor = {&const1[0],0,0,1,1};
    Calc_inp_const(&const1_tensor, Quant_tensor, &FC1_tensor);


    // ---- Tensor ULPPACK
    Tensor_PACK(Quant_tensor);


    int Quant_tmp[120];
    tensor_int Quant_tmp_tensor = {&Quant_tmp[0],0,0,1,120}; // zero and scale are invalid here
    #if (bit_width == 1)
    Quant_tmp_tensor.scale = 2;
    Quant_tmp_tensor.zero  = 0.5;
    #elif (bit_width == 2)
    Quant_tmp_tensor.scale = 1;
    Quant_tmp_tensor.zero  = 1;
    #elif (bit_width == 4)
    Quant_tmp_tensor.scale = 1/7.0;
    Quant_tmp_tensor.zero  = 7;
    #endif

    // ---- FC multiplication
    // ---- Weights of FC1 are transposed i.e.
    // ---- columns are in rows one after the other.
    // allocate 1*120 words of memory
    GEMM(&Quant_tmp_tensor, Quant_tensor, &FC1_tensor);

//    printf("RW:%d, CL:%d\n", Quant_tmp_tensor.RW, Quant_tmp_tensor.CL);
//    for(int i=0; i<Quant_tmp_tensor.RW*Quant_tmp_tensor.CL; i++)
//    {
//        printf("%d,\n", Quant_tmp_tensor.array[i]);
//    }

    // ---- Dequantize
    float Dequant[120];
    tensor_float Dequant_tensor = {&Dequant[0],0,0,1,120};
    Dequantize_res(&Dequant_tensor, &Quant_tmp_tensor, &FC1_tensor, &const1_tensor, &const2_3_tensor, const3_3);


    // ---- Batchnorm
    Batchnorm(&Dequant_tensor, &batchnorm3_tensor, false);


    // ---- Quantize numbers
    #if (bit_width == 1)
    Bimod_clamp_1bit(Quant_tensor, &Dequant_tensor);
    #elif (bit_width == 2)
    Trimod_clamp_2bit(Quant_tensor, &Dequant_tensor);
    #elif (bit_width == 4)
    Heptamod_clamp_4bit(Quant_tensor, &Dequant_tensor);
    #endif


    // ---- Quantize numbers to 0 and 1
    // ---- s = 2, z = 0.5
    #if (bit_width == 1)
    Quant_1bit(Quant_tensor, false);
    #elif (bit_width == 2)
    Quant_2bit(Quant_tensor, false);
    #elif (bit_width == 4)
    Quant_4bit(Quant_tensor, false);
    #endif

}

void fc2_layer(tensor_int* Quant_tensor)
{
    // ------------------------------
    // ----------- FC 2 -------------
    // --------- 120 -> 84 ----------

    // ---- Constant calculation
    // Const1_4 is calculated in runtime because input is not known in advance.
    float const1[1];
    tensor_float const1_tensor = {&const1[0],2,0.5,1,1};
    Calc_inp_const(&const1_tensor, Quant_tensor, &FC2_tensor);


    // ---- Tensor ULPPACK
    Tensor_PACK(Quant_tensor);


    // ---- FC multiplication
    // ---- Weights of FC1 are transposed i.e.
    // ---- columns are in rows one after the other.
    // allocate 1*84 words of memory
    int Quant_tmp[84];
    tensor_int Quant_tmp_tensor = {&Quant_tmp[0],0,0,1,84}; // zero and scale are invalid here
    #if (bit_width == 1)
    Quant_tmp_tensor.scale = 2;
    Quant_tmp_tensor.zero  = 0.5;
    #elif (bit_width == 2)
    Quant_tmp_tensor.scale = 1;
    Quant_tmp_tensor.zero  = 1;
    #elif (bit_width == 4)
    Quant_tmp_tensor.scale = 1/7.0;
    Quant_tmp_tensor.zero  = 7;
    #endif
    
    GEMM(&Quant_tmp_tensor, Quant_tensor, &FC2_tensor);


    // ---- Dequantize
    float Dequant[84];
    tensor_float Dequant_tensor = {&Dequant[0],0,0,1,84};
    Dequantize_res(&Dequant_tensor, &Quant_tmp_tensor, &FC2_tensor, &const1_tensor, &const2_4_tensor, const3_4);


    // ---- Batchnorm
    Batchnorm(&Dequant_tensor, &batchnorm4_tensor, false);


    // ---- Quantize numbers to -1 and 1
    #if (bit_width == 1)
    Bimod_clamp_1bit(Quant_tensor, &Dequant_tensor);
    #elif (bit_width == 2)
    Trimod_clamp_2bit(Quant_tensor, &Dequant_tensor);
    #elif (bit_width == 4)
    Heptamod_clamp_4bit(Quant_tensor, &Dequant_tensor);
    #endif

    // ---- Quantize numbers to 0 and 1
    // ---- s = 2, z = 0.5
    #if (bit_width == 1)
    Quant_1bit(Quant_tensor, false);
    #elif (bit_width == 2)
    Quant_2bit(Quant_tensor, false);
    #elif (bit_width == 4)
    Quant_4bit(Quant_tensor, false);
    #endif
}


int fc3_layer(tensor_int* Quant_tensor)
{

    // ------------------------------
    // ----------- FC 3 -------------
    // --------- 84 -> 10 -----------

    // ---- Constant calculation
    // Const1_5 is calculated in runtime because input is not known in advance.
    float const1[1];
    tensor_float const1_tensor = {&const1[0],2,0.5,1,1};
    Calc_inp_const(&const1_tensor, Quant_tensor, &FC3_tensor);


    // ---- Tensor ULPPACK
    Tensor_PACK(Quant_tensor);


    // ---- FC multiplication
    // ---- Weights of FC1 are transposed i.e.
    // ---- columns are in rows one after the other.
    // allocate 1*10 words of memory
    int Quant_tmp[10];
    tensor_int Quant_tmp_tensor = {&Quant_tmp[0],0,0,1,10}; // zero and scale are invalid here
    #if (bit_width == 1)
    Quant_tmp_tensor.scale = 2;
    Quant_tmp_tensor.zero  = 0.5;
    #elif (bit_width == 2)
    Quant_tmp_tensor.scale = 1;
    Quant_tmp_tensor.zero  = 1;
    #elif (bit_width == 4)
    Quant_tmp_tensor.scale = 1/7.0;
    Quant_tmp_tensor.zero  = 7;
    #endif
    
    GEMM(&Quant_tmp_tensor, Quant_tensor, &FC3_tensor);


    // ---- Dequantize
    float Dequant[10];
    tensor_float Dequant_tensor = {&Dequant[0],0,0,1,10};
    Dequantize_res(&Dequant_tensor, &Quant_tmp_tensor, &FC3_tensor, &const1_tensor, &const2_5_tensor, const3_5);


    // ---- Batchnorm
    Batchnorm(&Dequant_tensor, &batchnorm5_tensor, true); // true case for Tensor_norm
    

    float cls_tmp = 0;
    int cls_idx_tmp = 0;
    // printf("-------------------\n");
    for(int i=0; i<Dequant_tensor.RW * Dequant_tensor.CL; i++)
    {
        if(cls_tmp < Dequant_tensor.array[i])
        {
            cls_tmp = Dequant_tensor.array[i];
            cls_idx_tmp = i;
        }
        // printf("%f,\n", Dequant_tensor.array[i]);
    }

    return cls_idx_tmp;
}




// --------------------------------------------------------------------
// --------------------------------------------------------------------
// -------------------------- First Quantize --------------------------
// ----------------------------- Then Clip ----------------------------
// --------------------------------------------------------------------
// --------------------------------------------------------------------
// ---- Quantize input into 1-bit data and change scale and zero point
void Quant_1bit(tensor_int* x, bool polar_clip)
{
    int array_len = x->CL * x->RW;
    float temp = 0;
    for(int i=0; i<array_len; i++)
    {
        if(polar_clip)
        {
            temp = ((float)x->array[i] / x->scale) + x->zero;
//        printf("%i, %f,", i, temp);
            if(temp >= 0)
                x->array[i] = 1;
            else
                x->array[i] = -1;
        }
        else
        {
            if(x->array[i] >= 0)
                x->array[i] = 1;
            else
                x->array[i] = 0;
        }
//        x->array[i] = round(temp);
//        printf("%d, \n", x->array[i]);
    }
}
// --------------------------------------------------------------------
// --------------------------------------------------------------------
// --------------------------------------------------------------------
// --------------------------------------------------------------------


// --------------------------------------------------------------------
// --------------------------------------------------------------------
// -------------------------- First Quantize --------------------------
// ----------------------------- Then Clip ----------------------------
// --------------------------------------------------------------------
// --------------------------------------------------------------------
// ---- Quantize input into 1-bit data and change scale and zero point
void Quant_2bit(tensor_int* x, bool polar_clip)
{
//                printf("%f, %f, \n", x->scale, x->zero);
    int array_len = x->CL * x->RW;
    float temp = 0;
    for(int i=0; i<array_len; i++)
    {
        if(polar_clip)
        {
            temp = ((float)x->array[i] / x->scale) + x->zero;
//            printf("RW:%d, CL:%d\n", x->RW, x->CL);
//            for(int i=0; i<x->RW*x->CL; i++)
//            {
//                printf("%d, %d, %f, %f\n", i, x->array[i], temp, x->array[i] / x->scale - 1);
//            }
            if(temp > 0.5)
                x->array[i] = 1;
            else if(temp < -0.5)
                x->array[i] = -1;
            else
                x->array[i] = 0;

//            printf("RW:%d, CL:%d\n", x->RW, x->CL);
//            for(int i=0; i<x->RW*x->CL; i++)
//            {
//                printf("%d, %d, %f,\n", i, x->array[i], temp);
//            }
        }
        else
            // Two bit quantization has scale and zero equal to 1.
            x->array[i] = x->array[i] + x->zero;
//        printf("%d,\n", x->array[i]);
    }
}
// --------------------------------------------------------------------
// --------------------------------------------------------------------
// --------------------------------------------------------------------
// --------------------------------------------------------------------

// --------------------------------------------------------------------
// --------------------------------------------------------------------
// -------------------------- First Quantize --------------------------
// ----------------------------- Then Clip ----------------------------
// --------------------------------------------------------------------
// --------------------------------------------------------------------
// ---- Quantize input into 1-bit data and change scale and zero point
void Quant_4bit(tensor_int* x, bool polar_clip)
{
//                printf("%f, %f, \n", x->scale, x->zero);
    int array_len = x->CL * x->RW;
    float temp = 0;
    for(int i=0; i<array_len; i++)
    {
        if(polar_clip)
        {
            temp = ((float)x->array[i] / x->scale) + x->zero;
//             printf("%d, %d, %f", i, x->array[i], x->array[i] / x->scale);
            if(temp >= -0.5)
            {
                if(temp > 3.5)
                {
                    if(temp > 6.5)
                        x->array[i] = 7;
                    else if(temp > 5.5)
                        x->array[i] = 6;
                    else if(temp > 4.5)
                        x->array[i] = 5;
                    else
                        x->array[i] = 4;
                }
                else
                {
                    if(temp > 2.5)
                        x->array[i] = 3;
                    else if(temp > 1.5)
                        x->array[i] = 2;
                    else if(temp > 0.5)
                        x->array[i] = 1;
                    else
                        x->array[i] = 0;
                }
            }
            else
            {
                if(temp >= -3.5)
                {
                    if(temp >= -1.5)
                        x->array[i] = -1;
                    else if(temp >= -2.5)
                        x->array[i] = -2;
                    else
                        x->array[i] = -3;
                }
                else
                {
                    if(temp >= -4.5)
                        x->array[i] = -4;
                    else if(temp >= -5.5)
                        x->array[i] = -5;
                    else if(temp >= -6.5)
                        x->array[i] = -6;
                    else
                        x->array[i] = -7;
                }
            }

//             printf(";%d, %f,\n", x->array[i], temp);
        }
        else
            x->array[i] = x->array[i] + x->zero;
//        printf("%d,\n", x->array[i]);
    }
}
// --------------------------------------------------------------------
// --------------------------------------------------------------------
// --------------------------------------------------------------------
// --------------------------------------------------------------------


// --------------------------------------------------------------------
// --------------------------------------------------------------------
// --------------------------- Tensor Unfold --------------------------
// -- Extract inputs corresponfing to conv windows sliding over input--
// --------------------------------------------------------------------
// --------------------------------------------------------------------
// ---- To increase performance, the offsets containing multiplication is kept outside of
// ---- inner for loops.
void Unfold(tensor_int* o, tensor_int* x, int conv_win, int in_dim)
{

    int o_idx;
    int o_idx_const1;
    int o_idx_const2;
    int o_idx_const3;
    int o_idx_const4;

    int x_idx;
    int x_idx_const1;
    int x_idx_const2;
    int x_idx_const3;
    int x_idx_const4;

//    int in_dim = sqrt(x->CL);
//    int conv_win = 5; //number of elements in conv row
    int conv_dim = (in_dim - conv_win + 1); //resulting output dim
//    printf("in_dim:%d, conv_dim:%d\n", in_dim, conv_dim);
    for(int s=0; s<conv_dim; s++) // Slide conv window vertically
    {
        o_idx_const1 = s * conv_dim;
        x_idx_const1 = s * in_dim;
        for(int k=0; k<conv_dim; k++) // Slide conv window horizontally
        {
            o_idx_const2 = (o_idx_const1 + k) * conv_win * conv_win * x->RW;
            x_idx_const2 = x_idx_const1 + k;
            for(int p=0; p<x->RW; p++) // Traverse channels
            {
                o_idx_const3 = o_idx_const2 + p*conv_win * conv_win;
                x_idx_const3 = x_idx_const2 + p*x->CL;
//                printf("%d\n", o_idx_const3);
                for(int i=0; i<conv_win; i++) // Offset of rows in a window
                {
                    o_idx_const4 = i * conv_win + o_idx_const3;
                    x_idx_const4 = i * in_dim + x_idx_const3;
                    for(int j=0; j<conv_win; j++) // Offset of columns in a window
                    {
                        o_idx = j + o_idx_const4;
                        x_idx = j + x_idx_const4;
                        o->array[o_idx] = x->array[x_idx];
                    }
                }

            }
        }
    }

    o->RW = conv_dim * conv_dim;
    o->CL = conv_win * conv_win * x->RW;

// ---- Tesing
//    for(int e=0; e<14400; e++)
//    {
//        printf("%d,\n",o->array[e]);
//    }
    
}
// --------------------------------------------------------------------
// --------------------------------------------------------------------
// --------------------------------------------------------------------
// --------------------------------------------------------------------


// --------------------------------------------------------------------
// --------------------------------------------------------------------
// --------------------- Tensor ULPPACK over row ----------------------
// --------------------------------------------------------------------
// --------------------------------------------------------------------
void Tensor_ULPPACK_asym(tensor_int* x)
{   
    int pack_count;
    int depth, area_len;
    int tiled_inverse = 0;
    int x_idx = 0;
    int x_idx_const1 = 0;
    int x_idx_const2 = 0;

    int o_idx_const  = 0;

    int ulp_up_range = 0;
    int ulp_up_range_tmp = 0;
    
    switch(bit_width)
    {
        case 1:
        {
            depth = 8;
            area_len = 4;
            pack_count = x->CL / 8;
            if(x->CL%depth != 0)
                pack_count++;
            break;
        }
        case 2:
        {
            depth = 5;
            area_len = 6;
            pack_count = x->CL / 5;
            if(x->CL%depth != 0)
                pack_count++;
            break;
        }
        case 4:
        {
            depth = 3;
            area_len = 10;
            pack_count = x->CL / 3;
            if(x->CL%depth != 0)
                pack_count++;
            break;
        }
    }
    
//    printf("pack_count:%d, x->CL:%d, x->RW:%d\n", pack_count, x->CL, x->RW);
    int t, i, j;
    int temp;
        for(t=0; t<x->RW; t++) // Traverse rows
        {
            x_idx_const1 = t * x->CL;
            o_idx_const  = t * pack_count;
            for(i=0; i<pack_count-1; i++) // Traverse columns
            {
                temp = 0;
                x_idx_const2 = x_idx_const1 + depth*i;
                for(j=0; j<depth; j++)
                {
                    x_idx = x_idx_const2 +j;
                    temp = temp | (x->array[x_idx]<<(area_len*j));
                    // ---- For Tiled inverse:
//                    temp = temp | (x->array[x_idx]<<(area_len*(depth-j-1))); 
                }
                x->array[i + o_idx_const] = temp;
            }
            // ---- Last pack for asymmetric packing
            // i: pack_count - 1
            temp = 0;
            x_idx_const2 = x_idx_const1 + depth*(i);
            ulp_up_range = x->CL - depth*(i);
            for(j=0; j<ulp_up_range; j++)
            {   
                x_idx = x_idx_const2 + j;
                temp = temp | (x->array[x_idx]<<(area_len*j));
                // ---- For Tiled inverse:
//              temp = temp | (x->array[x_idx]<<(area_len*(depth-j-1)));
            }
            x->array[i + o_idx_const] = temp;
        }

// ---- Tesing
//    for(int e=0; e<pack_count; e++)
//    {
//        printf("%d,\n", x->array[e]);
//    }


    x->CL = pack_count;
}

// --------------------------------------------------------------------
// --------------------------------------------------------------------
// --------------------------------------------------------------------
// --------------------------------------------------------------------


// --------------------------------------------------------------------
// --------------------------------------------------------------------
// --------------- Calculate input const at runtime -------------------
// --------------------------------------------------------------------
// --------------------------------------------------------------------
// ---- Caclulate const1 which requires summation of input and scaling with zero point of weight
void Calc_inp_const(tensor_float* o, tensor_int* x, tensor_int* w)
{

    int idx, idx_const;
    int temp;
//     printf("%d,%d\n", x->RW, x->CL);
    for(int i=0; i<x->RW; i++)
    {
        temp = 0;
        idx_const = i*x->CL;

        for(int j=0; j<x->CL; j++)
        {
            //idx = i*CL + j;
            idx = idx_const + j;
            temp += x->array[idx];
//             printf("%d,", x->array[idx]);
        }
        o->array[i] = (float)temp * w->zero;
//         printf(" <i>:%d, %f\n", i, o->array[i]);
    }

    o->RW = 1;
    o->CL = x->RW;
// ---- Tesing
//     for(int e=0; e<o->RW*o->CL; e++)
//     {
//         printf("%f,\n", o->array[0]);
//     }
}

// --------------------------------------------------------------------
// --------------------------------------------------------------------
// --------------------------------------------------------------------
// --------------------------------------------------------------------


// --------------------------------------------------------------------
// --------------------------------------------------------------------
// -------------------------- Matrix Multiply -------------------------
// ------------------------------ x . yT ------------------------------
// ---------------- Equal to CONV when input is unfolded---------------
// --------------------------------------------------------------------
// ---- Matrix Multiplication of x and y while y is transposed (RW, CL of y are not changed after transposition)
void ulp_matrix_multiply_x_yT(tensor_int* o, tensor_int* x, tensor_int* y)
{
    // ---- multiply (x . yT)
    // ---- x_CL should be equal to y_CL
    // ---- y is stored in transposed format.
    int x_index;
    int y_index;
    int x_idx_const;
    int y_idx_const;
    int o_index;
    
    unsigned int result_mask;
    int shift;
    switch(bit_width)
    {
        case 1:
        {
            result_mask = 0xf0000000;
            shift = 28;
            break;
        }
        case 2:
        {
            result_mask = 0x3f000000;
            shift = 24;
            break;
        }
        case 4:
        {
            result_mask = 0x3ff00000;
            shift = 20;
            break;
        }
    }

    int temp = 0;

    for(int i=0; i<x->RW; i++)
    {
        x_idx_const = i * x->CL;
        for(int j=0; j<y->RW; j++)
        {
            y_idx_const = j * y->CL;
            o_index = j + i * y->RW;
            temp = 0;
            for(int k=0; k<x->CL; k++)
            {
                x_index = k + x_idx_const; //x_index = k + i * x_CL;
                y_index = k + y_idx_const; //y_index = k + j * y_CL;
                temp += ((x->array[x_index] * y->array[y_index])&result_mask) >> shift;
            }
            o->array[o_index] = temp;
        }
    }
//                printf("o->RW %d - o->CL %d\n", o->RW, o->CL);
    o->RW = x->RW;
    o->CL = y->RW;
    // ---- Tesing
//    for(int e=0; e<o->RW * o->CL; e++)
//    {
//        printf("%d,\n", o->array[e]);
//    }
}

void ulp_matrix_multiply_x_yT_CI(tensor_int* o, tensor_int* x, tensor_int* y)
{
    // ---- multiply (x . yT)
    // ---- x_CL should be equal to y_CL
    // ---- y is stored in transposed format.
    int x_index;
    int y_index;
    int x_idx_const;
    int y_idx_const;
    int o_index;

    int temp = 0;

    for(int i=0; i<x->RW; i++)
    {
        x_idx_const = i * x->CL;
        for(int j=0; j<y->RW; j++)
        {
            y_idx_const = j * y->CL;
            o_index = j + i * y->RW;
//            temp = 0;
            // Zero initialize CSR content (the CFU CSR0)
            neorv32_cpu_csr_write(CSR_CFUREG0, 0);
            for(int k=0; k<x->CL; k++)
            {
                x_index = k + x_idx_const; //x_index = k + i * x_CL;
                y_index = k + y_idx_const; //y_index = k + j * y_CL;
//                temp += ((x->array[x_index] * y->array[y_index])&result_mask) >> shift;
                #if (bit_width == 1)
                    temp = neorv32_cfu_r3_instr(0b0000000, 0b000, x->array[x_index], y->array[y_index]);
                #elif (bit_width == 2)
                    temp = neorv32_cfu_r3_instr(0b0000000, 0b001, x->array[x_index], y->array[y_index]);
                #elif (bit_width == 4)
                    temp = neorv32_cfu_r3_instr(0b0000000, 0b011, x->array[x_index], y->array[y_index]);
                #endif
            }
            o->array[o_index] = temp;
        }
    }
//                printf("o->RW %d - o->CL %d\n", o->RW, o->CL);
    o->RW = x->RW;
    o->CL = y->RW;
    // ---- Tesing
//    for(int e=0; e<o->RW * o->CL; e++)
//    {
//        printf("%d,\n", o->array[e]);
//    }
}


// --------------------------------------------------------------------
// --------------------------------------------------------------------
// --------------------------------------------------------------------
// --------------------------------------------------------------------

// --------------------------------------------------------------------
// --------------------------------------------------------------------
// ----------------------------- Dequantize ---------------------------
// --------------------------------------------------------------------
// --------------------------------------------------------------------
// --------------------------------------------------------------------
// ---- Convert the result into float to perform batchnorm
void Dequantize_res(tensor_float* o, tensor_int* x, tensor_int* y, tensor_float* const1, tensor_float* const2, float const3)
{
    // ---- Const1: constant float for each row of input
    // ---- Const2: constant float for each column of input
    // ---- Const3: constant float for each number of input
    // ---- + Final scale
    for(int i=0; i<x->RW; i++)
    {
        for(int j=0; j<x->CL; j++)
        {
            o->array[j + i*x->CL] = (x->array[j + i*x->CL] - const1->array[i] - const2->array[j] + const3)*x->scale*y->scale;
//             printf("i:%d, j:%d, o:%f, x:%d, const1:%f, const2:%f, const3:%f, x:%f, y:%f\n", i, j, o->array[j + i*x->CL], x->array[j + i*x->CL], const1->array[i], const2->array[i], const3, x->scale, y->scale);
        }
    }

    o->RW = x->RW;
    o->CL = x->CL;
}
// --------------------------------------------------------------------
// --------------------------------------------------------------------
// --------------------------------------------------------------------
// --------------------------------------------------------------------


// --------------------------------------------------------------------
// --------------------------------------------------------------------
// ----------------------------- BatchNorm ----------------------------
// --------------------------------------------------------------------
// --------------------------------------------------------------------
// --------------------------------------------------------------------
// ---- Convert the result into float to perform batchnorm
// ---- It works for 2D and 1D tensors (output of Conv and FC layers)
void Batchnorm(tensor_float* x, tensor_float* batchnorm, bool Tensor_norm)
{
    // ----                    offset
    // ---- Batchnorm_scale        0
    // ---- Batchnorm_offset       0 + batchnorm->CL
    float temp       =   0;
    int offset_idx   =   batchnorm->CL;
    if(Tensor_norm == false)
    {
        for(int i=0; i<x->RW; i++)
        {
            for(int j=0; j<x->CL; j++)
            {
//                printf("i:%d, x:%f, ", j + i*x->CL, x->array[j + i*x->CL]);
                x->array[j + i*x->CL] = (batchnorm->array[0 + j] * x->array[j + i*x->CL]) + batchnorm->array[offset_idx + j];
//                printf("o:%f, scale:%f, zero:%f\n", x->array[j + i*x->CL], batchnorm->array[0 + j], batchnorm->array[offset_idx + j]);
            }
        }
    }
    else
    {
        for(int i=0; i<x->RW; i++)
        {
            for(int j=0; j<x->CL; j++)
            {
                x->array[j + i*x->CL] = (batchnorm->array[0] * x->array[j + i*x->CL]) + batchnorm->array[offset_idx];
            }
        }
    }


}
// --------------------------------------------------------------------
// --------------------------------------------------------------------
// --------------------------------------------------------------------
// --------------------------------------------------------------------


// --------------------------------------------------------------------
// --------------------------------------------------------------------
// ----------------------- Bimodal clamp (-1, 1) ----------------------
// --------------------------------------------------------------------
// --------------------------------------------------------------------
// --------------------------------------------------------------------
void Bimod_clamp_1bit(tensor_int* o, tensor_float* x)
{
    int array_len = x->CL * x->RW;
    for(int i=0; i<array_len; i++)
    {
        if(x->array[i] > 0)
            o->array[i] = 1;
        else
            o->array[i] = -1;
//        printf("%d,\n", o->array[i]);
    }
    
    o->RW = x->RW;
    o->CL = x->CL;
}
// --------------------------------------------------------------------
// --------------------------------------------------------------------
// --------------------------------------------------------------------
// --------------------------------------------------------------------

// --------------------------------------------------------------------
// --------------------------------------------------------------------
// -------------------- Trimodal clamp (-1, 0, 1) ---------------------
// --------------------------------------------------------------------
// --------------------------------------------------------------------
// --------------------------------------------------------------------
void Trimod_clamp_2bit(tensor_int* o, tensor_float* x)
{
    int array_len = x->CL * x->RW;
    for(int i=0; i<array_len; i++)
    {
        if(x->array[i] > 0.5)
            o->array[i] = 1;
        else if(x->array[i] < -0.5)
            o->array[i] = -1;
        else
            o->array[i] = 0;
//        printf("%d,\n", o->array[i]);
    }
    
    o->RW = x->RW;
    o->CL = x->CL;
}
// --------------------------------------------------------------------
// --------------------------------------------------------------------
// --------------------------------------------------------------------
// --------------------------------------------------------------------

// --------------------------------------------------------------------
// --------------------------------------------------------------------
// -------------------- Heptamodal clamp (-7:7) -----------------------
// --------------------------------------------------------------------
// --------------------------------------------------------------------
// --------------------------------------------------------------------
void Heptamod_clamp_4bit(tensor_int* o, tensor_float* x)
{
    int array_len = x->CL * x->RW;
    for(int i=0; i<array_len; i++)
    {
        if(x->array[i] >= -0.5)
        {
            if(x->array[i] > 3.5)
            {
                if(x->array[i] > 6.5)
                    o->array[i] = 7;
                else if(x->array[i] > 5.5)
                    o->array[i] = 6;
                else if(x->array[i] > 4.5)
                    o->array[i] = 5;
                else
                    o->array[i] = 4;
            }
            else
            {
                if(x->array[i] > 2.5)
                    o->array[i] = 3;
                else if(x->array[i] > 1.5)
                    o->array[i] = 2;
                else if(x->array[i] > 0.5)
                    o->array[i] = 1;
                else
                    o->array[i] = 0;
            }
        }
        else
        {
            if(x->array[i] >= -3.5)
            {
                if(x->array[i] >= -1.5)
                    o->array[i] = -1;
                else if(x->array[i] >= -2.5)
                    o->array[i] = -2;
                else
                    o->array[i] = -3;
            }
            else
            {
                if(x->array[i] >= -4.5)
                    o->array[i] = -4;
                else if(x->array[i] >= -5.5)
                    o->array[i] = -5;
                else if(x->array[i] >= -6.5)
                    o->array[i] = -6;
                else
                    o->array[i] = -7;
            }
        }
//         printf("%d, %f\n", o->array[i], x->array[i]);
    }
    
    o->RW = x->RW;
    o->CL = x->CL;
}
// --------------------------------------------------------------------
// --------------------------------------------------------------------
// --------------------------------------------------------------------
// --------------------------------------------------------------------

// --------------------------------------------------------------------
// --------------------------------------------------------------------
// --------------------------- Transpose ------------------------------
// --------------------------------------------------------------------
// --------------------------------------------------------------------
// --------------------------------------------------------------------
// ---- Each column contains a channel of data
void Transpose(tensor_int* x)
{
    int temp = 0;
    int src_const = 0;
    int dest_const = 0;
    int i_range;
    int j_range;

    int Transposed[max_transpose_numel];

    for(int i=0; i<x->RW; i++)
    {
        for(int j=0; j<x->CL; j++)
        {
            Transposed[j*x->RW + i] = x->array[i*x->CL + j];
        }
    }
    
    int range_tmp = x->RW*x->CL;
    for(int i=0; i<range_tmp; i++)
    {
        x->array[i] = Transposed[i];
    }

    temp  = x->RW;
    x->RW = x->CL;
    x->CL = temp;
}
// --------------------------------------------------------------------
// --------------------------------------------------------------------
// --------------------------------------------------------------------
// --------------------------------------------------------------------


// --------------------------------------------------------------------
// --------------------------------------------------------------------
// --------------------------- MAXPOOL2D ------------------------------
// --------------------------------------------------------------------
// --------------------------------------------------------------------
// --------------------------------------------------------------------
// ---- Each row contains a channel of data
void Maxpool2D(tensor_int* x, int in_dim)
{
    int o_idx;
    int o_idx_const0;
    int o_idx_const1;
    int o_idx_const2;
    int o_idx_const3;

    int x_idx;
    int x_idx_const0;
    int x_idx_const1;
    int x_idx_const2;
    int x_idx_const3;

    int pool_dim = (1 + (in_dim - 2)/2);

    int max_temp = 0;

    for(int r=0; r<x->RW; r++) // Perform maxpool for different channels
    {
        o_idx_const0 = r * pool_dim * pool_dim;
        x_idx_const0 = r * in_dim * in_dim;
        for(int s=0; s<pool_dim; s++) // Slide pool window vertically
        {
            o_idx_const1 = s * pool_dim + o_idx_const0;
            x_idx_const1 = 2 * s * in_dim + x_idx_const0;
            for(int k=0; k<pool_dim; k++) // Slide conv window horizontally
            {
                o_idx = o_idx_const1 + k;
                x_idx_const2 = 2 * k + x_idx_const1;
                max_temp = -1;
                for(int i=0; i<2; i++) // Offset of rows in a window
                {
                    x_idx_const3 = i * in_dim + x_idx_const2;
                    for(int j=0; j<2; j++) // Offset of columns in a window
                    {
                        x_idx = j + x_idx_const3;
                        if(x->array[x_idx] > max_temp)
                        {
                            max_temp = x->array[x_idx];
                        }
//                            printf("%d, %d\n", x_idx, o_idx);
                    }
                }
                x->array[o_idx] = max_temp;
            }
        }

    }
//    printf("%d\n", pool_dim);
    x -> CL = pool_dim * pool_dim;
}
// --------------------------------------------------------------------
// --------------------------------------------------------------------
// --------------------------------------------------------------------
// --------------------------------------------------------------------



// ----------------- Verified inefficient codes
//void Unfold(tensor_int* o, tensor_int* x)
//{
//
//
//    for(int s=0; s<24; s++) // Slide conv window vertically
//    {
//        for(int k=0; k<24; k++) // Slide conv window horizontally
//        {
//            for(int i=0; i<5; i++) // Offset of rows in a window
//            {
//                for(int j=0; j<5; j++) // Offset of columns in a window
//                {
//                    o->array[j + i * 5 + (s * 24 + k) *25] = x->array[(j + i * 28 + s * 28 + k)];
//                }
//            }
//        }
//    }

//    for(int e=0; e<14400; e++)
//    {
//        printf("%d,\n",o->array[e]);
//    }
//    
//}

//void Unfold(tensor_int* o, tensor_int* x)
//{
//    int o_idx;
//    int o_idx_const1;
//    int o_idx_const2;
//    int o_idx_const3;
//
//    int x_idx;
//    int x_idx_const1;
//    int x_idx_const2;
//    int x_idx_const3;
//    int in_dim = sqrt(x->CL);
//    int conv_dim = (in_dim - 4);
//
//    for(int s=0; s<24; s++) // Slide conv window vertically
//    {
//        o_idx_const1 = s * 24;
//        x_idx_const1 = s * 28;
//        for(int k=0; k<24; k++) // Slide conv window horizontally
//        {
//            o_idx_const2 = (o_idx_const1 + k) *25;
//            x_idx_const2 = x_idx_const1 + k;
//            for(int i=0; i<5; i++) // Offset of rows in a window
//            {
//                o_idx_const3 = i * 5 + o_idx_const2;
//                x_idx_const3 = i * 28 + x_idx_const2;
//                for(int j=0; j<5; j++) // Offset of columns in a window
//                {
//                    o_idx = j + o_idx_const3;
//                    x_idx = j + x_idx_const3;
//                    o->array[o_idx] = x->array[x_idx];
//                }
//            }
//        }
//    }
//
// ---- Tesing
//    for(int e=0; e<14400; e++)
//    {
//        printf("%d,\n",o->array[e]);
//    }
//    
//}
//


//// -------------- Write to main memory - bypass cache ----------------
void amowrite(uint32_t addr, uint32_t wdata)
{

  uint32_t status;

  while(1) 
  {
    neorv32_cpu_amolr(addr);
    status = neorv32_cpu_amosc(addr, wdata);
    if (status == 0) 
    {
        break;
    }
  }
}
